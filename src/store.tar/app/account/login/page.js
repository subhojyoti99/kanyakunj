"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import useAuthStore from "../../../store/authStore";

export default function LoginPage() {
  const [tab, setTab] = useState("login"); // "login" | "register"
  const [form, setForm] = useState({ email: "", password: "", firstName: "", lastName: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const { setUser } = useAuthStore();
  const router = useRouter();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email, password: form.password }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Login failed. Please check your credentials.");
        return;
      }

      setUser(data);
      router.push("/account");
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: "70vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "60px 24px", background: "var(--ivory)" }}>
      <div style={{ width: "100%", maxWidth: 420 }}>

        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <span style={{ fontFamily: "'Jost', sans-serif", fontSize: 11, letterSpacing: 3, textTransform: "uppercase", color: "var(--gold)", fontWeight: 500 }}>
            Welcome Back
          </span>
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 38, fontWeight: 400, color: "var(--charcoal)", margin: "8px 0 0", lineHeight: 1.1 }}>
            {tab === "login" ? "Sign In" : "Create Account"}
          </h1>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", borderBottom: "1px solid var(--border)", marginBottom: 32 }}>
          {["login", "register"].map((t) => (
            <button
              key={t}
              onClick={() => { setTab(t); setError(""); }}
              style={{
                flex: 1,
                paddingBottom: 12,
                background: "none",
                border: "none",
                borderBottom: `2px solid ${tab === t ? "var(--gold)" : "transparent"}`,
                fontFamily: "'Jost', sans-serif",
                fontSize: 12,
                fontWeight: 500,
                letterSpacing: 2,
                textTransform: "uppercase",
                color: tab === t ? "var(--gold)" : "var(--warm-gray)",
                cursor: "pointer",
                transition: "all 0.2s",
                marginBottom: -1,
              }}
            >
              {t === "login" ? "Sign In" : "Register"}
            </button>
          ))}
        </div>

        {/* Error */}
        {error && (
          <div style={{ background: "#fff0f0", border: "1px solid #ffd0d0", borderRadius: 4, padding: "12px 16px", marginBottom: 20, fontFamily: "'Jost', sans-serif", fontSize: 13, color: "#c0392b" }}>
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit}>
          {tab === "register" && (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
              <div>
                <label className="acc-label">First Name</label>
                <input className="acc-input" value={form.firstName} onChange={e => setForm({ ...form, firstName: e.target.value })} required />
              </div>
              <div>
                <label className="acc-label">Last Name</label>
                <input className="acc-input" value={form.lastName} onChange={e => setForm({ ...form, lastName: e.target.value })} required />
              </div>
            </div>
          )}

          <div style={{ marginBottom: 16 }}>
            <label className="acc-label">Email Address</label>
            <input className="acc-input" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
          </div>

          <div style={{ marginBottom: 24 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
              <label className="acc-label" style={{ marginBottom: 0 }}>Password</label>
              {tab === "login" && (
                <a href="#" style={{ fontFamily: "'Jost', sans-serif", fontSize: 11, color: "var(--gold)", textDecoration: "none" }}>
                  Forgot password?
                </a>
              )}
            </div>
            <input className="acc-input" type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required />
          </div>

          <button
            type="submit"
            className="btn-primary"
            style={{ width: "100%", fontSize: 12, letterSpacing: 2, padding: "14px 24px" }}
            disabled={loading}
          >
            {loading ? "Please wait…" : tab === "login" ? "Sign In" : "Create Account"}
          </button>
        </form>

        <p style={{ textAlign: "center", fontFamily: "'Jost', sans-serif", fontSize: 12, color: "var(--warm-gray)", marginTop: 24 }}>
          {tab === "login" ? "New customer? " : "Already have an account? "}
          <button onClick={() => { setTab(tab === "login" ? "register" : "login"); setError(""); }}
            style={{ background: "none", border: "none", color: "var(--gold)", cursor: "pointer", fontFamily: "'Jost', sans-serif", fontSize: 12, fontWeight: 500 }}>
            {tab === "login" ? "Create account" : "Sign in"}
          </button>
        </p>
      </div>

      <style>{`
        .acc-label {
          display: block;
          font-family: 'Jost', sans-serif;
          font-size: 10px;
          font-weight: 600;
          letter-spacing: 1.5px;
          text-transform: uppercase;
          color: var(--warm-gray);
          margin-bottom: 8px;
        }
        .acc-input {
          width: 100%;
          box-sizing: border-box;
          background: #fff;
          border: 1.5px solid var(--border);
          border-radius: 4px;
          padding: 12px 14px;
          font-family: 'Jost', sans-serif;
          font-size: 13px;
          color: var(--charcoal);
          outline: none;
          transition: border-color 0.2s;
        }
        .acc-input:focus { border-color: var(--gold); }
      `}</style>
    </div>
  );
}
