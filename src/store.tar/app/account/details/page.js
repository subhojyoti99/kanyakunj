"use client";
import { useState } from "react";
import useAuthStore from "../../../store/authStore";

export default function AccountDetailsPage() {
  const { user, setUser } = useAuthStore();
  const [form, setForm] = useState({
    firstName: user?.firstName || "",
    lastName: user?.lastName || "",
    email: user?.email || "",
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.newPassword && form.newPassword !== form.confirmPassword) {
      setMessage({ type: "error", text: "New passwords do not match." });
      return;
    }

    setSaving(true);
    setMessage(null);

    try {
      const payload = {
        first_name: form.firstName,
        last_name: form.lastName,
        email: form.email,
      };
      if (form.newPassword) {
        payload.password = form.newPassword;
      }

      const res = await fetch(`/api/wc/customers?wcId=${user.wcId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        setUser({ ...user, firstName: form.firstName, lastName: form.lastName, email: form.email });
        setMessage({ type: "success", text: "Account details saved successfully!" });
        setForm(f => ({ ...f, currentPassword: "", newPassword: "", confirmPassword: "" }));
      } else {
        setMessage({ type: "error", text: "Failed to update details. Please try again." });
      }
    } catch {
      setMessage({ type: "error", text: "Something went wrong." });
    } finally {
      setSaving(false);
    }
  };

  const Field = ({ label, name, type = "text" }) => (
    <div style={{ marginBottom: 20 }}>
      <label style={{ display: "block", fontFamily: "'Jost', sans-serif", fontSize: 10, fontWeight: 600, letterSpacing: 1.5, textTransform: "uppercase", color: "var(--warm-gray)", marginBottom: 8 }}>
        {label}
      </label>
      <input
        type={type}
        value={form[name]}
        onChange={e => setForm({ ...form, [name]: e.target.value })}
        style={{ width: "100%", boxSizing: "border-box", background: "#fff", border: "1.5px solid var(--border)", borderRadius: 4, padding: "12px 14px", fontFamily: "'Jost', sans-serif", fontSize: 13, color: "var(--charcoal)", outline: "none" }}
        onFocus={e => { e.target.style.borderColor = "var(--gold)"; }}
        onBlur={e => { e.target.style.borderColor = "var(--border)"; }}
        suppressHydrationWarning
      />
    </div>
  );

  return (
    <div>
      <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 30, fontWeight: 400, color: "var(--charcoal)", marginBottom: 32 }}>
        Account Details
      </h2>

      {message && (
        <div style={{
          background: message.type === "success" ? "#f0faf0" : "#fff0f0",
          border: `1px solid ${message.type === "success" ? "#c3e6cb" : "#ffd0d0"}`,
          borderRadius: 4, padding: "12px 16px", marginBottom: 24,
          fontFamily: "'Jost', sans-serif", fontSize: 13,
          color: message.type === "success" ? "#2d7a2d" : "#c0392b",
        }}>
          {message.text}
        </div>
      )}

      <form onSubmit={handleSubmit} style={{ maxWidth: 520 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 20px" }}>
          <Field label="First Name" name="firstName" />
          <Field label="Last Name" name="lastName" />
        </div>
        <Field label="Email Address" name="email" type="email" />

        {/* Password section */}
        <div style={{ borderTop: "1px solid var(--border)", paddingTop: 28, marginTop: 8, marginBottom: 28 }}>
          <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 22, fontWeight: 400, color: "var(--charcoal)", marginBottom: 20 }}>
            Change Password
          </h3>
          <p style={{ fontFamily: "'Jost', sans-serif", fontSize: 12, color: "var(--warm-gray)", marginBottom: 20 }}>
            Leave blank to keep current password.
          </p>
          <Field label="Current Password" name="currentPassword" type="password" />
          <Field label="New Password" name="newPassword" type="password" />
          <Field label="Confirm New Password" name="confirmPassword" type="password" />
        </div>

        <button
          type="submit"
          className="btn-primary"
          style={{ fontSize: 11, letterSpacing: 2, padding: "14px 32px" }}
          disabled={saving}
          suppressHydrationWarning
        >
          {saving ? "Saving…" : "Save Changes"}
        </button>
      </form>
    </div>
  );
}
