import { NextResponse } from "next/server";
import api from "../../../../lib/woocommerce";

export async function POST(req) {
  try {
    const { email, password } = await req.json();

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password required" }, { status: 400 });
    }

    // Verify credentials against WordPress REST API
    const credentials = Buffer.from(`${email}:${password}`).toString("base64");
    const wpRes = await fetch(`${process.env.NEXT_PUBLIC_WC_URL}/wp-json/wp/v2/users/me`, {
      headers: { Authorization: `Basic ${credentials}` },
    });

    if (!wpRes.ok) {
      return NextResponse.json({ error: "Invalid email or password" }, { status: 401 });
    }

    const wpUser = await wpRes.json();

    // Get customer WooCommerce data using admin API keys
    const { data: customers } = await api.get("customers", { email });
    const customer = customers?.[0];

    return NextResponse.json({
      id: wpUser.id,
      wcId: customer?.id || null,
      firstName: customer?.first_name || wpUser.name?.split(" ")[0] || "",
      lastName: customer?.last_name || wpUser.name?.split(" ")[1] || "",
      email: customer?.email || email,
      avatarUrl: wpUser.avatar_urls?.["96"] || null,
    });
  } catch (err) {
    console.error("Login error:", err.message);
    return NextResponse.json({ error: "Login failed" }, { status: 500 });
  }
}
