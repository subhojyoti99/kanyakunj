import { create } from "zustand";
import { persist } from "zustand/middleware";

const useAuthStore = create(
  persist(
    (set) => ({
      user: null, // { id, firstName, lastName, email, wcId }

      setUser: (user) => set({ user }),

      logout: () => {
        set({ user: null });
      },
    }),
    {
      name: "kanyakunj-auth",
    }
  )
);

export default useAuthStore;
